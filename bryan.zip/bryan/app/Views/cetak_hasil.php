<!-- cetak_hasil.php -->
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Print Result</h1>
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>jumlah</th>
                        <th>harga</th>
                        <th>kategori</th>
                        <th>jenis bensin</th>
                        <th>tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($formulir as $key => $row) { ?>
                        <tr>
                            <td><?= $key + 1 ?></td>
                            <td><?= $row->jumlah ?></td>
                            <td><?= $row->harga ?></td>
                            <td><?= $row->kategori ?></td>
                            <td><?= $row->jenis_bensin ?></td>
                            <td><?= $row->tanggal ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
