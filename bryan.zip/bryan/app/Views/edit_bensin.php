<main id="main" class="main">

    <div class="pagetitle">
      <h1>Form Elements</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item active">Elements</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">

<div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Form edit</h5>

      <div class="container mt-3">
        <form action="<?= base_url('home/aksi_edit_bensin') ?>" method="POST">
          <div class="mb-3 mt-3">
            <label for="inputText" class="col-sm-2 col-form-label">jumlah</label>
            <div class="col-sm-10">
              <input type="int" required class="form-control" name="jumlah" value="<?= $satu->jumlah ?>">
            </div>
          </div>
          <div class="mb-3">
            <label for="inputText" class="col-sm-2 col-form-label">harga</label>
            <div class="col-sm-10">
              <input type="int" required class="form-control" name="harga" value="<?= $satu->harga ?>">
            </div>
          </div>
          <div class="mb-3">
            <label for="inputText" class="col-sm-2 col-form-label">kategori</label>
            <div class="col-sm-10">
              <select  type="select" class="form-control" name="kategori" id="kategori" placeholder="Enter kategori" name="kategori" value="<?= $satu->kategori ?>">
               <option value="volvo">Pilih status</option>
               <option value="1">motor</option>
               <option value="2">mobil</option>
             </select>
           </div>
         </div>

         <div class="mb-3">
            <label for="inputText" class="col-sm-2 col-form-label">jenis bensin</label>
            <div class="col-sm-10">
              <select  type="select" class="form-control" name="jenis_bensin" id="jenis bensin" placeholder="Enter kategori" name="jenis_bensin" value="<?= $satu->jenis_bensin ?>">
               <option value="volvo">Pilih status</option>
               <option value="1">pertalite</option>
               <option value="2">premium</option>
               <option value="3">pertamax</option>
               <option value="4">solar</option>
             </select>
           </div>
         </div>
         <div class="mb-3">
            <label for="inputText" class="col-sm-2 col-form-label">tanggal</label>
            <div class="col-sm-10">
              <input type="date" required class="form-control" name="tanggal" value="<?= $satu->tanggal ?>">
            </div>
          </div>
          <div class="row mb-3">
            <label class="col-sm-2 col-form-label"></label>
            <div class="col-sm-10">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </div>

          <input type="hidden" name="id" value="<?= $satu->id_bensin ?>">
        </form>
       </div>
          </div>

        </div>
