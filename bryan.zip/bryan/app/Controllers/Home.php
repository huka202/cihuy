<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_bryan;

class Home extends BaseController
{
    public function login()
    {
        echo view ('header');
        echo view('login');
    }
    public function aksi_login()
    {
        $u=$this->request->getPost('username');
        $p=$this->request->getPost('pw');

        $model = new M_bryan();
        $where=array(
            'username'=> $u,
            'pw'=> $p
        );
        $model = new M_bryan();
        $cek = $model->getWhere('user',$where);

        if ($cek>0){
           session()->set('id_user',$cek->id_user);
           session()->set('username',$cek->username);
           session()->set('pw',$cek->pw);
           session()->set('level',$cek->id_level);
           return redirect()->to('home/dashboard');
        }else{
        return redirect()->to('home/login');
    }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('home/login');
    }

    public function dashboard()
    {
        if (session()->get('level')>0){
        echo view ('header');
        echo view ('menu');
        echo view('dashboard');
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function level()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        $data['manda'] = $model->join('user','level','user.id_level=level.id_level', 'id_user');
        echo view ('header');
        echo view ('menu');
        echo view('level',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function user()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        $data['manda'] = $model->join('user','level','user.id_level=level.id_level', 'id_user');
        echo view ('header');
        echo view ('menu');
        echo view('user',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function tambah_user()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        echo view ('header');
        echo view ('menu');
        echo view('tambah_user');
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function aksi_t_user()
    {
        $model = new M_bryan();
        $a = $this->request->getPost('username');
        $b = $this->request->getPost('pw');
        $c = $this->request->getPost('level');
        $isi = array(
            'username' => $a,
            'pw' => $b,
            'id_level' => $c
        );
        $model ->tambah('user', $isi);

        return redirect()->to('home/user');
    }

    public function hapus_user($id){
        $model = new M_bryan();
        $where=array('id_user'=>$id);
        $model->hapus('user',$where);
        return redirect()->to('home/user');
    }

    public function edit_user($id){
        if (session()->get('level')>0){
        $model = new M_bryan();
        $where=array('id_user'=>$id);

        $data['satu']=$model->getWhere('user',$where);

        echo view ('header');
        echo view ('menu',$data);
        echo view ('edit_user',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function aksi_edit_user()
    {
        $model = new M_bryan();
        $a = $this->request->getPost('username');
        $b = $this->request->getPost('pw');
        $id = $this->request->getPost('id');

        $where=array('id_user'=>$id);

        $isi = array(
            'username' => $a,
            'pw' => $b

        );
        $model ->edit('user', $isi,$where);

        return redirect()->to('home/user');
    }

    public function bensin()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        $data['manda'] = $model->tampil('bensin', 'id_bensin');
        echo view ('header');
        echo view ('menu');
        echo view('bensin',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function tambah_bensin()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        echo view ('header');
        echo view ('menu');
        echo view('tambah_bensin');
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
        
    }

    public function aksi_t_bensin()
    {
        $model = new M_bryan();
        $a = $this->request->getPost('jumlah');
        $b = $this->request->getPost('harga');
        $c = $this->request->getPost('kategori');
        $d = $this->request->getPost('jenis_bensin');
        $e = $this->request->getPost('tanggal');
        $isi = array(
            'jumlah' => $a,
            'harga' => $b,
            'kategori' => $c,
            'jenis_bensin' => $d,
            'tanggal' => $e
        );
        $model ->tambah('bensin', $isi);

        return redirect()->to('home/pengeluaran');
    }

    public function hapus_bensin($id){
        $model = new M_bryan();
        $where=array('id_bensin'=>$id);
        $model->hapus('bensin',$where);
        return redirect()->to('home/bensin');
    }

    public function edit_bensin($id){
        if (session()->get('level')>0){
        $model = new M_bryan();
        $where=array('id_bensin'=>$id);

        $data['satu']=$model->getWhere('bensin',$where);

        echo view ('header');
        echo view ('menu',$data);
        echo view ('edit_bensin',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function aksi_edit_bensin()
    {
        $model = new M_bryan();
        $a = $this->request->getPost('jumlah');
        $b = $this->request->getPost('harga');
        $c = $this->request->getPost('kategori');
        $d = $this->request->getPost('jenis_bensin');
        $e = $this->request->getPost('tanggal');
        $id = $this->request->getPost('id');

        $where=array('id_bensin'=>$id);

        $isi = array(
            'jumlah' => $a,
            'harga' => $b,
            'kategori' => $c,
            'jenis_bensin' => $d,
            'tanggal' => $e
        );
        $model ->edit('bensin', $isi,$where);

        return redirect()->to('home/bensin');
    }

    public function laporan()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        echo view ('header');
        echo view ('menu');
        echo view('laporan');
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function generate_pdf()
    {
        $this->laporan_pdf();
    }

    private function laporan_pdf()
    {
        $model = new M_amanda();

        $start_date = $this->request->getPost('start_date'); 
        $end_date = $this->request->getPost('end_date'); 

        $data['laporan'] = $model->getLaporanByDate($start_date, $end_date); 
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isRemoteEnabled', true);
        $dompdf = new Dompdf($options);


        $html = view('laporan_pdf', $data);

        $dompdf->loadHtml($html);
        $dompdf->render();
        $dompdf->stream("laporan.pdf");
    }





    public function generate_window()
    {
        echo view('header');
        echo view('menu');
        echo view('laporan');
        echo view('footer');
    }

    public function generate_window_result()
    {
        // Ambil data formulir berdasarkan rentang waktu dari request POST
        $start_date = $this->request->getPost('start_date');
        $end_date = $this->request->getPost('end_date');
        $model = new M_bryan();
        $data['bensin'] = $model->getLaporanByDate($start_date, $end_date);

        echo view('cetak_hasil', $data);
    }




    public function generate_excel()
    {
        $model = new M_bryan();
        $start_date = $this->request->getPost('start_date'); 
        $end_date = $this->request->getPost('end_date'); 


        $data['bensin'] = $model->getLaporanByDateForExcel($start_date, $end_date);
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getProperties()->setCreator("Your Name")
        ->setLastModifiedBy("Your Name")
        ->setTitle("Laporan Booking")
        ->setSubject("Laporan Booking")
        ->setDescription("Laporan Booking")
        ->setKeywords("PHPExcel")
        ->setCategory("Test result file");


        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'jumlah')
        ->setCellValue('B1', 'harga')
        ->setCellValue('C1', 'kategori')
        ->setCellValue('D1', 'jenis_bensin')
        ->setCellValue('E1', 'tanggal');


        $rowCount = 2;
        foreach ($data['bensin'] as $row) {
            $sheet->setCellValue('A'.$rowCount, $row['jumlah'])
            ->setCellValue('B'.$rowCount, $row['harga'])
            ->setCellValue('C'.$rowCount, $row['kategori'])
            ->setCellValue('D'.$rowCount, $row['jenis_bensin'])
            ->setCellValue('E'.$rowCount, $row['tanggal']);
            $rowCount++;
        }


        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="laporan_dokter.xlsx"');
        header('Cache-Control: max-age=0');

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
    }
}
