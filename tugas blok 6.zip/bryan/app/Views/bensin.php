<main id="main" class="main">

  <div class="pagetitle">
    <h1>Data Bensin</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= base_url('home/dashboard')?>">Home</a></li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">
      <div class="col-lg-12">

        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Bensin</h5>

            <a href="<?= base_url('home/tambah_bensin') ?>">
             <button class="ri-keyboard-line"></button>
           </a>
           <table class="table datatable">
            <thead>
              <tr>
                <th scope="col">no</th>
                <th scope="col">Jumlah Bensin</th>
                <th scope="col">Harga Bensin</th>
                <th scope="col">Kategori</th>
                <th scope="col">Jenis Bensin</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php

              $no=1;
              foreach($manda as $erwin){
               ?>	

               <tr>
                <td><?= $no++ ?></td>
                <td><?=$erwin->jumlah?></td>
                <td><?= $erwin ->harga?></td>
                <td><?= $erwin ->kategori?></td>
                <td><?= $erwin ->jenis_bensin?></td>
                <td><?= $erwin ->tanggal?></td>
                <td>


                 
                 <a href="<?= base_url('home/edit_bensin/' . $erwin ->id_bensin) ?>">
                   <button class="bi bi-pencil-square"></button>
                 </a>

                 <a href="<?= base_url('home/hapus_bensin/' . $erwin ->id_bensin) ?>">
                   <button class="ri-delete-bin-6-line"></button>
                 </a>
               </td>
               <td>
                 <img src="<?php echo base_url('img/'.$erwin ->foto)?>" width="80px">
               </td>
             </tr>
           <?php } ?>
         </tbody>
       </table>
       <!-- End Table with stripped rows -->

     </div>
   </div>

 </div>
</div>
</section>

</main><!-- End #main -->

<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
  </div>
  <div class="credits">
    <!-- All the links in the footer should remain intact. -->
    <!-- You can delete the links only if you purchased the pro version. -->
    <!-- Licensing information: https://bootstrapmade.com/license/ -->
    <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
    Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
  </div>
</footer><!-- End Footer -->

