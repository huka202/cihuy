<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

          <li class="nav-item dropdown pe-3">

            <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
              

              <span class="d-none d-md-block dropdown-toggle ps-2"><?= session()->get('username')?></span>
            </a><!-- End Profile Iamge Icon -->

            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
              <li class="dropdown-header">
              </li>
              <li>
                <hr class="dropdown-divider">
              </li>

              <li>
              </li>
              <li>
                <hr class="dropdown-divider">
              </li>

              <li>
                <a class="dropdown-item d-flex align-items-center" href="<?= base_url('home/setting')?>">
                  <i class="bi bi-gear"></i>
                  <span>Account Settings</span>
                </a>
              </li>
              <li>
                <hr class="dropdown-divider">
              </li>

              <li>
                <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                  <i class="bi bi-question-circle"></i>
                  <span>Need Help?</span>
                </a>
              </li>
              <li>
                <hr class="dropdown-divider">
              </li>

              <li>
                <a class="dropdown-item d-flex align-items-center" href="<?= base_url('home/logout')?>">
                  <i class="bi bi-box-arrow-right"></i>
                  <span>Sign Out</span>
                </a>
              </li>

            </ul><!-- End Profile Dropdown Items -->
          </li><!-- End Profile Nav -->

        </ul>
      </nav><!-- End Icons Navigation -->

    </header><!-- End Header -->

    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">

      <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
          <a class="nav-link " href="<?= base_url ('home/dashboard')?>">
            <i class="bi bi-grid"></i>
            <span>Dashboard</span>
          </a>
        </li><!-- End Dashboard Nav -->

        <?php
        if(session()->get('level')==1 || session()->get('level')==2 || session()->get('level')==3){
          ?>

          <li class="nav-item">
            <a class="nav-link collapsed" href="<?= base_url ('home/bensin')?>">
              <i class="bi bi-caret-right"></i><span>bensin</span>
            </a>
          </li><!-- End Components Nav -->
        <?php } ?>



        <?php
        if(session()->get('level')==1 || session()->get('level')==2 || session()->get('level')==4){
          ?>

        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-caret-right"></i><span>Laporan</span><i class="bi bi-chevron-down ms-auto"></i>
          </a>
          <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
              <a href="<?= base_url ('home/laporan')?>">
                <i class="bi bi-circle"></i><span>Laporan</span>
              </a>
            </li>
          </ul>
        </li><!-- End babi Nav -->

      <?php } ?>

      <?php
        if(session()->get('level')==2 || session()->get('level')==1){
          ?>

        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#x-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-bar-chart"></i><span>Data Personal</span><i class="bi bi-chevron-down ms-auto"></i>
          </a>
          <ul id="x-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
              <a href="<?= base_url ('home/user')?>">
                <i class="bi bi-circle"></i><span>User</span>
              </a>
            </li>
            <li>
              <a href="<?= base_url ('home/level')?>">
                <i class="bi bi-circle"></i><span>Level</span>
              </a>
            </li>
          </ul>
        </li><!-- End Charts Nav -->
        <?php } ?>

      </ul>

    </aside><!-- End Sidebar-->
