<main id="main" class="main">

  <div class="pagetitle">
    <h1>Data Bensin</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= base_url('home/dashboard')?>">Home</a></li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">
      <div class="col-lg-12">

        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Level</h5>
<table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">no</th>
                                <th scope="col">Username</th>
                                <th scope="col">Password</th>
                                <th scope="col">Level</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            $no = 1;
                            foreach ($manda as $erwin) {
                                ?>

                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $erwin->username ?></td>
                                    <td><?= $erwin->pw ?></td>
                                    <td><?= $erwin->id_level ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    </div>
   </div>

 </div>
</div>
</section>

</main><!-- End #main -->


