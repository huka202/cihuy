<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_bryan;

class Home extends BaseController
{
    public function login()
    {
        echo view ('header');
        echo view('login');
    }
    public function aksi_login()
    {
        $u=$this->request->getPost('username');
        $p=$this->request->getPost('pw');

        $model = new M_bryan();
        $where=array(
            'username'=> $u,
            'pw'=> $p
        );
        $model = new M_bryan();
        $cek = $model->getWhere('user',$where);

        if ($cek>0){
           session()->set('id_user',$cek->id_user);
           session()->set('username',$cek->username);
           session()->set('pw',$cek->pw);
           session()->set('level',$cek->id_level);
           return redirect()->to('home/dashboard');
        }else{
        return redirect()->to('home/login');
    }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('home/login');
    }

    public function dashboard()
    {
        if (session()->get('level')>0){
        echo view ('header');
        echo view ('menu');
        echo view('dashboard');
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function level()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        $data['manda'] = $model->join('user','level','user.id_level=level.id_level', 'id_user');
        echo view ('header');
        echo view ('menu');
        echo view('level',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function user()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        $data['manda'] = $model->join('user','level','user.id_level=level.id_level', 'id_user');
        echo view ('header');
        echo view ('menu');
        echo view('user',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function tambah_user()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        echo view ('header');
        echo view ('menu');
        echo view('tambah_user');
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function aksi_t_user()
    {
        $model = new M_bryan();
        $a = $this->request->getPost('username');
        $b = $this->request->getPost('pw');
        $c = $this->request->getPost('level');
        $isi = array(
            'username' => $a,
            'pw' => $b,
            'id_level' => $c
        );
        $model ->tambah('user', $isi);

        return redirect()->to('home/user');
    }

    public function hapus_user($id){
        $model = new M_bryan();
        $where=array('id_user'=>$id);
        $model->hapus('user',$where);
        return redirect()->to('home/user');
    }

    public function edit_user($id){
        if (session()->get('level')>0){
        $model = new M_bryan();
        $where=array('id_user'=>$id);

        $data['satu']=$model->getWhere('user',$where);

        echo view ('header');
        echo view ('menu',$data);
        echo view ('edit_user',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function aksi_edit_user()
    {
        $model = new M_bryan();
        $a = $this->request->getPost('username');
        $b = $this->request->getPost('pw');
        $id = $this->request->getPost('id');

        $where=array('id_user'=>$id);

        $isi = array(
            'username' => $a,
            'pw' => $b

        );
        $model ->edit('user', $isi,$where);

        return redirect()->to('home/user');
    }

    public function bensin()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        $data['manda'] = $model->tampil('bensin', 'id_bensin');
        echo view ('header');
        echo view ('menu');
        echo view('bensin',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function tambah_bensin()
    {
        if (session()->get('level')>0){
        $model = new M_bryan();
        echo view ('header');
        echo view ('menu');
        echo view('tambah_bensin');
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
        
    }

    public function aksi_t_bensin()
    {
        $model = new M_bryan();
        $a = $this->request->getPost('jumlah');
        $b = $this->request->getPost('harga');
        $c = $this->request->getPost('kategori');
        $d = $this->request->getPost('jenis_bensin');
        $e = $this->request->getPost('tanggal');
        $isi = array(
            'jumlah' => $a,
            'harga' => $b,
            'kategori' => $c,
            'jenis_bensin' => $d,
            'tanggal' => $e
        );
        $model ->tambah('bensin', $isi);

        return redirect()->to('home/pengeluaran');
    }

    public function hapus_bensin($id){
        $model = new M_bryan();
        $where=array('id_bensin'=>$id);
        $model->hapus('bensin',$where);
        return redirect()->to('home/bensin');
    }

    public function edit_bensin($id){
        if (session()->get('level')>0){
        $model = new M_bryan();
        $where=array('id_bensin'=>$id);

        $data['satu']=$model->getWhere('bensin',$where);

        echo view ('header');
        echo view ('menu',$data);
        echo view ('edit_bensin',$data);
        echo view ('footer');
        }else{
            return redirect()->to('home/login');
        }
    }

    public function aksi_edit_bensin()
    {
        $model = new M_bryan();
        $a = $this->request->getPost('jumlah');
        $b = $this->request->getPost('harga');
        $c = $this->request->getPost('kategori');
        $d = $this->request->getPost('jenis_bensin');
        $e = $this->request->getPost('tanggal');
        $id = $this->request->getPost('id');

        $where=array('id_bensin'=>$id);

        $isi = array(
            'jumlah' => $a,
            'harga' => $b,
            'kategori' => $c,
            'jenis_bensin' => $d,
            'tanggal' => $e
        );
        $model ->edit('bensin', $isi,$where);

        return redirect()->to('home/bensin');
    }
}
